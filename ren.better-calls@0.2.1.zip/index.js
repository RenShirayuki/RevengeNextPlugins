export default (() => {
// BetterCalls -> Revenge Next (plain JS port, single file) v0.2.0
//
// The loader runs this file as a function body during preInit, when most of
// `revenge.*` doesn't exist yet. So NOTHING touches `revenge` at the top level:
// all lookups happen in start() via resolveApis(). If a lookup fails, start()
// throws an error that lists the real names under revenge.*, so the error text
// tells us what to fix.

/* ============================ API RESOLUTION ============================== */
const A = {}; // filled by resolveApis() in start()

// first non-null result among candidates (a candidate that throws is skipped)
const first = (...fns) => {
	for (const fn of fns) {
		try {
			const v = fn();
			if (v !== undefined && v !== null) return v;
		} catch (_) {}
	}
};
// run candidates until one doesn't throw
const attempt = (...fns) => {
	for (const fn of fns) {
		try {
			return fn();
		} catch (_) {}
	}
};

const keys = (o) => {
	try {
		return Object.getOwnPropertyNames(o).slice(0, 60).join(", ");
	} catch (_) {
		return "(unavailable)";
	}
};

function describeApis() {
	const r = revenge;
	return [
		"--- available names (send this to Claude) ---",
		`revenge: ${keys(r)}`,
		`modules: ${keys(r.modules)}`,
		`modules.finders: ${keys(r.modules && r.modules.finders)}`,
		`react: ${keys(r.react)}`,
		`assets: ${keys(r.assets)}`,
		`components: ${keys(r.components)}`,
		`discord: ${keys(r.discord)}`,
		`discord.common: ${keys(r.discord && r.discord.common)}`,
	].join("\n");
}

function resolveApis() {
	const r = revenge;
	A.finders = first(() => r.modules.finders, () => r.modules); // GUESS
	A.React = first(
		() => r.react.React,
		() => (r.react.createElement ? r.react : undefined),
		() => r.discord.common.React,
		() => globalThis.React,
	); // GUESS
	A.RN = first(
		() => r.react.ReactNative,
		() => r.discord.common.ReactNative,
		() => globalThis.ReactNative,
		() => A.finders.findByProps("ScrollView", "View"),
	); // GUESS
	A.C = first(() => r.components); // GUESS: Stack, TableRow, TableRowGroup, ... under revenge.components
	A.assets = first(() => r.assets);

	const missing = [];
	if (!A.finders) missing.push("finders");
	if (!A.React) missing.push("React");
	if (!A.RN) missing.push("ReactNative");
	if (!A.C) missing.push("components");
	if (missing.length) throw new Error(`BetterCalls: cannot find ${missing.join(", ")}`);
}

// Lazy handles so the rest of the code can keep using React.x / RN.x / C.x
const lazy = (name) => new Proxy({}, { get: (_, k) => A[name][k] });
const React = lazy("React");
const RN = lazy("RN");
const C = lazy("C");
const h = (...args) => A.React.createElement(...args);

const findByProps = (...p) => A.finders.findByProps(...p); // GUESS
const findByTypeName = (n) => first(() => A.finders.findByTypeName(n), () => A.finders.findByName(n)); // GUESS

const findAssetId = (name) =>
	first(
		() => A.assets.findAssetId(name),
		() => A.assets.getAssetIdByName(name),
		() => A.assets.getIdByName(name),
		() => A.assets.findByName(name).id,
	); // GUESS (missing icons just don't show)

const showToast = (content, icon) =>
	attempt(
		() => revenge.discord.toasts.open({ key: "better-calls:toast", content, icon }),
		() => revenge.discord.toasts.showToast(content, icon),
	); // GUESS (silently does nothing if unavailable)

const showSheet = (key, Component) =>
	attempt(
		() => revenge.discord.sheets.show(key, Component),
		() => revenge.discord.sheets.showActionSheet(key, Promise.resolve({ default: Component })),
		() => revenge.components.showSheet(key, Component),
	); // GUESS

/* ------------------------------ tiny patcher ------------------------------ */
// Own implementation so we don't depend on Next's patcher API.
// NOTE: if a module's exports are frozen/non-writable this will silently fail.
function patchMethod(obj, name, make) {
	const orig = obj[name];
	obj[name] = make(orig);
	return () => {
		obj[name] = orig;
	};
}

// cb(args, returnValue) -> return a value to replace the result
const after = (obj, name, cb) =>
	patchMethod(obj, name, (orig) =>
		function (...args) {
			const ret = orig.apply(this, args);
			const out = cb(args, ret);
			return out === undefined ? ret : out;
		},
	);

// cb(args, originalFn, thisArg) -> you decide whether to call the original
const instead = (obj, name, cb) =>
	patchMethod(obj, name, (orig) =>
		function (...args) {
			return cb(args, orig, this);
		},
	);

/* -------------------------------- storage --------------------------------- */
// Backed by api.jsonStorage (async file storage). We keep the loaded object in
// memory, mutate it, and write it back with set(data, true).
const DEFAULTS = {
	silentCall: { enabled: true, default: false, users: {} },
	rememberOutputDevice: { enabled: false, device: undefined },
};

function createStorage(data, js) {
	for (const k of Object.keys(DEFAULTS)) {
		if (data[k] === undefined) data[k] = JSON.parse(JSON.stringify(DEFAULTS[k]));
	}
	const walk = (path) => path.split(".");
	const save = () => {
		try {
			const p = js.set(data, true);
			if (p && p.catch) p.catch(() => {});
		} catch (_) {}
	};
	return {
		get: (path) => walk(path).reduce((o, k) => (o == null ? undefined : o[k]), data),
		set(path, value) {
			const ks = walk(path);
			const last = ks.pop();
			const parent = ks.reduce((o, k) => (o[k] = o[k] || {}), data);
			parent[last] = value;
			save();
			return true;
		},
		unset(path) {
			const ks = walk(path);
			const last = ks.pop();
			const parent = ks.reduce((o, k) => (o == null ? undefined : o[k]), data);
			if (parent) delete parent[last];
			save();
			return true;
		},
		getFirstDefined(...paths) {
			for (const p of paths) {
				const v = this.get(p);
				if (v !== undefined) return v;
			}
		},
	};
}

let storage; // set in start()
let audio; // set in start()
let unpatches = { silentCall: [], rememberOutputDevice: [] };

/* --------------------------- audio device helpers -------------------------- */
function createAudio() {
	const { getAudioDevices } = findByProps("getAudioDevices");
	const { setAudioOutputDevice } = findByProps("setAudioOutputDevice");
	const { audioDeviceToIconMap, getAudioDeviceToDisplayText } = findByProps("audioDeviceToIconMap");
	return {
		getAudioDevices: () => getAudioDevices(),
		setAudioOutputDevice: (d) => setAudioOutputDevice(d),
		getAudioDeviceIcon: (type) => audioDeviceToIconMap[type],
		getAudioDeviceDisplayText: (d) => getAudioDeviceToDisplayText(d),
	};
}

function showAudioOutputDevicesSelectionSheet(props) {
	showSheet("better-calls:audio-output-devices-select", () =>
		h(C.ErrorBoundary, null, h(AudioOutputDevicesSelectionSheet, props)),
	);
}

/* ------------------------------ silent call patch ------------------------- */
const NextPreference = { undefined: true, true: false, false: undefined };

const Preferences = {
	undefined: {
		icon: "BellIcon",
		description: "Following the global setting for this user",
		buttonVariant: "tertiary",
		action: (cid) => storage.unset(`silentCall.users.${cid}`),
	},
	true: {
		icon: "BellZIcon",
		description: "Calling will now silently call this user",
		buttonVariant: "primary",
		action: (cid) => storage.set(`silentCall.users.${cid}`, true),
	},
	false: {
		icon: "ic_notification_settings_24px",
		description: "Calling will now ring this user",
		buttonVariant: "secondary",
		action: (cid) => storage.set(`silentCall.users.${cid}`, false),
	},
};

function patchSilentCall(out) {
	const callModule = findByProps("call", "ring", "stopRinging");
	const PrivateChannelButtons = findByTypeName("PrivateChannelButtons");
	if (!callModule || !PrivateChannelButtons) return; // fail silently like the original

	// Structure: <PrivateChannelButtons><Fragment><IconButton/>...
	out.push(
		after(PrivateChannelButtons, "type", ([{ channelId }], rt) => {
			// hooks are fine here, we're running inside the component's render
			const [silenced, setSilenced] = React.useState(storage.get(`silentCall.users.${channelId}`));

			const key = String(silenced);
			const pref = Preferences[key];
			const fragmentProps = rt && rt.props && rt.props.children && rt.props.children[0] && rt.props.children[0].props;

			// Can be undefined while in a call (buttons are replaced by hang up). Bot DMs give an object.
			if (fragmentProps && Array.isArray(fragmentProps.children)) {
				fragmentProps.children = [
					h(C.IconButton, {
						key: "better-calls:silent-call-toggle",
						icon: findAssetId(pref.icon),
						variant: pref.buttonVariant,
						size: "sm",
						onPress: () => {
							const next = NextPreference[key];
							setSilenced(next);
							const nextPref = Preferences[String(next)];
							nextPref.action(channelId);
							showToast(nextPref.description, findAssetId(nextPref.icon));
						},
					}),
					...fragmentProps.children,
				];
			}
		}),
	);

	out.push(
		instead(callModule, "ring", (args, ring, self) => {
			const silent = storage.getFirstDefined(`silentCall.users.${args[0]}`, "silentCall.default");
			if (!silent) return ring.apply(self, args);
		}),
	);
}

/* ------------------------ remember output device patch -------------------- */
function patchRememberOutputDevice(out) {
	const VoicePanelHeaderSpeaker = findByTypeName("VoicePanelHeaderSpeaker");
	if (!VoicePanelHeaderSpeaker) return;

	out.push(
		after(VoicePanelHeaderSpeaker, "type", ([props]) => {
			if (!props.isConnectedToVoiceChannel) return;
			const device = storage.get("rememberOutputDevice.device");
			if (!device) return; // guard added: original would crash here with no device

			// Same as the original: re-applies the saved device on every render while connected
			audio.setAudioOutputDevice(device);

			return h(C.IconButton, {
				key: "better-calls:output-device-button",
				icon: audio.getAudioDeviceIcon(device.simpleDeviceType),
				variant: "primary-overlay",
				size: "sm",
				onPress: () => showAudioOutputDevicesSelectionSheet({ fromVoiceCall: true }),
			});
		}),
	);
}

/* ---------------------------- patch lifecycle ------------------------------ */
function clear(key) {
	for (const u of unpatches[key]) u();
	unpatches[key] = [];
}

function syncPatches() {
	const devices = audio.getAudioDevices();
	const cur = storage.get("rememberOutputDevice.device");
	// Reset if nothing saved or the saved device is gone
	if (!cur || !devices.some((d) => d.deviceId === cur.deviceId && d.deviceType === cur.deviceType)) {
		storage.set("rememberOutputDevice.device", devices[0]);
	}

	if (!storage.get("silentCall.enabled")) clear("silentCall");
	else if (!unpatches.silentCall.length) patchSilentCall(unpatches.silentCall);

	if (!storage.get("rememberOutputDevice.enabled")) clear("rememberOutputDevice");
	else if (!unpatches.rememberOutputDevice.length) patchRememberOutputDevice(unpatches.rememberOutputDevice);
}

/* -------------------------------- UI: sheet -------------------------------- */
function AudioOutputDevicesSelectionSheet({ onPress, fromVoiceCall }) {
	const devices = audio.getAudioDevices();

	return h(
		C.ActionSheet,
		null,
		h(
			RN.View,
			null,
			h(
				C.Stack,
				{ spacing: 16 },
				h(C.BottomSheetTitleHeader, { title: "Select Preferred Audio Output Device" }),
				h(
					C.Stack,
					{ spacing: 12 },
					h(
						C.TableRadioGroup,
						{
							title: "Audio Devices",
							hasIcons: true,
							value: storage.get("rememberOutputDevice.device.deviceId"),
							onChange: (deviceId) => {
								const device = devices.find((d) => d.deviceId === deviceId);
								if (!device) return;
								storage.set("rememberOutputDevice.device", device);
								audio.setAudioOutputDevice(device);
								if (onPress) onPress();
							},
						},
						devices.map((device) =>
							h(C.TableRadioRow, {
								key: String(device.deviceId),
								icon: h(C.TableRow.Icon, { source: audio.getAudioDeviceIcon(device.simpleDeviceType) }),
								label: audio.getAudioDeviceDisplayText(device),
								subLabel: device.deviceName,
								value: device.deviceId,
							}),
						),
					),
				),
				fromVoiceCall &&
					h(
						C.Stack,
						{ spacing: 0 },
						h(
							C.Text,
							{ variant: "text-xs/normal", color: "TEXT_MUTED" },
							"Missing a few devices from the stock panel? Swipe up the dock and use ",
							h(C.Text, { variant: "text-xs/bold" }, "Change Audio Output"),
							".",
						),
					),
			),
		),
	);
}

/* ------------------------------ UI: settings ------------------------------- */
function SettingsPage() {
	// Plugin not started yet (e.g. disabled): nothing to show
	if (!storage || !audio || !A.React) return null;

	const [, forceUpdate] = React.useReducer((x) => ~x, 0);
	const onUpdate = () => {
		syncPatches();
		forceUpdate();
	};
	const muted = { variant: "text-xs/normal", color: "TEXT_MUTED" };
	const device = storage.get("rememberOutputDevice.device");

	return h(
		C.ErrorBoundary,
		null,
		h(
			RN.ScrollView,
			{ style: { flex: 1 }, contentContainerStyle: { paddingBottom: 38 } },
			h(
				C.Stack,
				{ style: { paddingVertical: 24, paddingHorizontal: 12 }, spacing: 24 },

				// ---- Silent Call ----
				h(
					C.Stack,
					{ spacing: 12 },
					h(
						C.TableRowGroup,
						{ title: "Silent Call" },
						h(C.TableSwitchRow, {
							icon: h(C.TableRow.Icon, { source: findAssetId("ic_notif_off") }),
							label: "Enable Silent Call",
							subLabel: "Silently call someone without ringing, configurable per user.",
							value: storage.get("silentCall.enabled"),
							onValueChange: (v) => {
								storage.set("silentCall.enabled", v);
								onUpdate();
							},
						}),
						h(C.TableSwitchRow, {
							icon: h(C.TableRow.Icon, { source: findAssetId("ic_call_ended") }),
							label: "Ring by default",
							subLabel: "Ring people by default unless you set otherwise. This will affect unset preferences.",
							value: !storage.get("silentCall.default"),
							onValueChange: (v) => {
								storage.set("silentCall.default", !v);
								onUpdate();
							},
						}),
						h(C.TableRow, {
							variant: "danger",
							icon: h(C.TableRow.Icon, { variant: "danger", source: findAssetId("ic_message_delete") }),
							label: "Reset preferences",
							subLabel: "Reset all silent call preferences, this will make you ring people by default again.",
							onPress: () => {
								storage.set("silentCall.users", {});
								showToast("Silent call preferences have been reset", findAssetId("ic_message_delete"));
							},
						}),
					),
					h(
						C.Text,
						muted,
						"You may need to switch between DMs and servers for the changes to take effect. This is because Discord caches rendered components.",
					),
				),

				// ---- Remember Audio Output Device ----
				h(
					C.Stack,
					{ spacing: 12 },
					h(
						C.TableRowGroup,
						{ title: "Remember Audio Output Device" },
						h(C.TableSwitchRow, {
							icon: h(C.TableRow.Icon, { source: findAssetId("voice_bar_speaker_new") }),
							label: "Remember audio output device",
							subLabel: "Remembers your audio output device preferences.",
							value: storage.get("rememberOutputDevice.enabled"),
							onValueChange: (v) => {
								storage.set("rememberOutputDevice.enabled", v);
								onUpdate();
							},
						}),
						h(C.TableRow, {
							disabled: !storage.get("rememberOutputDevice.enabled"),
							icon: h(C.TableRow.Icon, {
								source: audio.getAudioDeviceIcon(device ? device.simpleDeviceType : "INVALID"),
							}),
							label: "Current device",
							subLabel: device
								? `${device.deviceName} - ${audio.getAudioDeviceDisplayText(device)}`
								: "No device",
							arrow: true,
							onPress: () => showAudioOutputDevicesSelectionSheet({ onPress: forceUpdate }),
						}),
					),
					h(
						C.Text,
						muted,
						"If your device is not persistent, the first device will be selected after the preferred device is removed.",
					),
					h(
						C.Text,
						muted,
						"This also replaces the audio output device selection sheet, so it may be missing features such as transferring voice chats to a console. Alternatively, swipe up the dock in the voice call UI and use ",
						h(C.Text, { variant: "text-xs/bold" }, "Change Audio Output"),
						".",
					),
				),
			),
		),
	);
}

/* --------------------------------- plugin ---------------------------------- */
// Shape follows PluginOptions from lib/plugins: lifecycles + SettingsComponent,
// plus `jsonStorage` (read by the revenge.api plugin to create api.jsonStorage).
const options = {
	jsonStorage: { default: DEFAULTS },

	start(api) {
		const fail = (e) => {
			throw new Error(`${(e && e.message) || e}\n\n${describeApis()}`);
		};
		try {
			resolveApis();
			const js = api.jsonStorage || (this && this.api && this.api.jsonStorage);
			if (!js) throw new Error("BetterCalls: api.jsonStorage is missing");

			return js
				.get()
				.then((data) => {
					storage = createStorage(data, js);
					audio = createAudio();
					syncPatches();
					api.cleanup(() => {
						clear("silentCall");
						clear("rememberOutputDevice");
						storage = undefined;
						audio = undefined;
					});
				})
				.catch(fail);
		} catch (e) {
			fail(e);
		}
	},

	SettingsComponent: SettingsPage,
};

// Mirror the official build output (`export default plugin({...})`): use the
// loader's plugin() helper when it exists, otherwise hand back the plain object.
const wrapped = typeof plugin === "function" ? plugin(options) : undefined;
return wrapped && typeof wrapped === "object" ? wrapped : options;
})();
