export default plugin((() => {
// Better Calls for Revenge Next - written from scratch against the real Revenge Next API
// (names taken from k1ng_op's Instant Actions: finders.lookupModule/filters.withProps,
// patcher.instead, discord.actions.*, discord.design.Design, assets.getAssetIdByName,
// jsonStorage with default/load/cache/use/set). Anything not seen in a real plugin is
// looked up defensively; whatever can't be found shows up under "Diagnostics" in settings.

const DEFAULTS = {
	silentCallEnabled: true,
	silentCallDefault: false, // false = ring by default
	silentCallUsers: {}, // channelId -> "silent" | "ring" | "default"
	rememberDeviceEnabled: false,
	rememberDeviceId: undefined,
	rememberDeviceType: undefined,
};

const NEXT_PREF = { default: "silent", silent: "ring", ring: "default" };
const PREFS = {
	default: { icon: "BellIcon", text: "Following the global setting for this user", variant: "tertiary" },
	silent: { icon: "BellZIcon", text: "Calling will now silently call this user", variant: "primary" },
	ring: { icon: "ic_notification_settings_24px", text: "Calling will now ring this user", variant: "secondary" },
};

let jsonStorage;
let audio;
const missing = []; // things we couldn't find, shown in settings

const cfg = () => jsonStorage?.cache ?? DEFAULTS;
const save = (patch) => jsonStorage.set(patch);

/* ------------------------------- helpers ---------------------------------- */
const attempt = (...fns) => {
	for (const fn of fns) {
		try {
			const v = fn();
			if (v !== undefined && v !== null) return v;
		} catch (_) {}
	}
};
const keys = (o) => {
	try {
		return Object.getOwnPropertyNames(o).slice(0, 50).join(", ");
	} catch (_) {
		return "(unavailable)";
	}
};
const need = (name, value) => {
	if (value === undefined || value === null) missing.push(name);
	return value;
};

const lookup = (...props) => {
	const f = revenge.modules.finders;
	return f.lookupModule(f.filters.withProps(...props))[0];
};

// Component modules ({ type }) by name. The exact filter name is unverified, so try a few.
const findComponent = (name) => {
	const f = revenge.modules.finders;
	const F = f.filters;
	const tryFilter = (fname) => () => {
		const m = f.lookupModule(F[fname](name))[0];
		return m && m.type ? m : undefined;
	};
	return attempt(
		tryFilter("withTypeName"),
		tryFilter("byTypeName"),
		tryFilter("withName"),
		tryFilter("byName"),
		tryFilter("withDisplayName"),
		tryFilter("byDisplayName"),
		() => f.findByTypeName(name),
	);
};

let hCache;
const h = (type, props, ...children) => {
	if (!hCache) {
		const R = attempt(() => revenge.react.React, () => (revenge.react.createElement ? revenge.react : undefined));
		if (R) hCache = R.createElement.bind(R);
		else {
			const jsx = attempt(() => revenge.react.jsx, () => revenge.react.jsxRuntime.jsx, () => revenge.react.runtime.jsx);
			if (!jsx) throw new Error(`Better Calls: no createElement/jsx in revenge.react (${keys(revenge.react)})`);
			hCache = (t, p, ...c) => jsx(t, { ...p, children: c.length > 1 ? c : c[0] }, p && p.key);
		}
	}
	return hCache(type, props, ...children);
};

const Design = () => revenge.discord.design.Design;
const asset = (name) => attempt(() => revenge.assets.getAssetIdByName(name));

const toast = (content, icon) =>
	attempt(
		() => Design().showToast({ key: "better-calls:toast", content, icon }),
		() => Design().toasts.open({ key: "better-calls:toast", content, icon }),
	);

const openSheet = (key, Component, props) =>
	attempt(() => revenge.discord.actions.ActionSheetActionCreators.openLazy(Promise.resolve({ default: Component }), key, props) ?? true);

// after() built on patcher.instead(): cb(args, ret) may return a replacement
const patchAfter = (obj, name, cb) =>
	revenge.patcher.instead(obj, name, (args, original) => {
		const ret = original(...args);
		const out = cb(args, ret);
		return out === undefined ? ret : out;
	});

/* ------------------------------ audio devices ------------------------------ */
const createAudio = () => {
	const a = need("module: getAudioDevices", lookup("getAudioDevices"));
	const s = need("module: setAudioOutputDevice", lookup("setAudioOutputDevice"));
	const i = need("module: audioDeviceToIconMap", lookup("audioDeviceToIconMap"));
	if (!a || !s || !i) return undefined;
	return {
		list: () => a.getAudioDevices(),
		set: (d) => s.setAudioOutputDevice(d),
		icon: (type) => i.audioDeviceToIconMap[type],
		text: (d) => i.getAudioDeviceToDisplayText(d),
	};
};

const savedDevice = (list, c) => list.find((d) => d.deviceId === c.rememberDeviceId && d.deviceType === c.rememberDeviceType);
const saveDevice = (d) => save({ rememberDeviceId: d.deviceId, rememberDeviceType: d.deviceType });

/* ----------------------------- UI: device sheet ---------------------------- */
const DeviceSheet = () => {
	const D = Design();
	const c = jsonStorage.use() ?? DEFAULTS;
	const list = audio.list();
	const current = savedDevice(list, c);
	return h(
		D.ActionSheet,
		null,
		h(
			D.Stack,
			{ spacing: 16 },
			h(D.BottomSheetTitleHeader, { title: "Select Preferred Audio Output Device" }),
			h(
				D.TableRadioGroup,
				{
					title: "Audio Devices",
					hasIcons: true,
					value: current ? current.deviceId : undefined,
					onChange: (id) => {
						const d = list.find((x) => x.deviceId === id);
						if (!d) return;
						saveDevice(d);
						audio.set(d);
					},
				},
				list.map((d) =>
					h(D.TableRadioRow, {
						key: String(d.deviceId),
						icon: h(D.TableRow.Icon, { source: audio.icon(d.simpleDeviceType) }),
						label: audio.text(d),
						subLabel: d.deviceName,
						value: d.deviceId,
					}),
				),
			),
		),
	);
};

const chooseDevice = () => {
	const D = Design();
	// Fallback if the sheet components don't exist: cycle through the devices
	if (!D.ActionSheet || !D.TableRadioGroup || !D.TableRadioRow || !D.BottomSheetTitleHeader || !D.Stack) {
		const list = audio.list();
		const idx = list.findIndex((d) => d === savedDevice(list, cfg()));
		const next = list[(idx + 1) % list.length];
		if (next) {
			saveDevice(next);
			audio.set(next);
			toast(`Output device: ${audio.text(next)}`);
		}
		return;
	}
	openSheet("better-calls:audio-output-devices", DeviceSheet, {});
};

/* ------------------------------ UI: settings ------------------------------- */
const Settings = ({ api }) => {
	const D = Design();
	const { Page } = revenge.components;
	const { ScrollView } = revenge.react.ReactNative;
	const store = api.jsonStorage;
	const c = store.use() ?? DEFAULTS;
	const list = audio ? audio.list() : [];
	const device = savedDevice(list, c);
	const icon = (name) => h(D.TableRow.Icon, { source: asset(name) });

	return h(
		Page,
		null,
		h(
			ScrollView,
			{ style: { flex: 1 }, contentContainerStyle: { paddingBottom: 40, gap: 16 } },

			h(
				D.TableRowGroup,
				{ title: "Silent Call" },
				h(D.TableSwitchRow, {
					icon: icon("ic_notif_off"),
					label: "Enable Silent Call",
					subLabel: "Silently call someone without ringing, configurable per user (bell button in DMs). You may need to switch DMs/servers for it to show.",
					value: c.silentCallEnabled,
					onValueChange: (v) => store.set({ silentCallEnabled: v }),
				}),
				h(D.TableSwitchRow, {
					icon: icon("ic_call_ended"),
					label: "Ring by default",
					subLabel: "Ring people unless you set otherwise. Affects users without their own preference.",
					value: !c.silentCallDefault,
					onValueChange: (v) => store.set({ silentCallDefault: !v }),
				}),
				h(D.TableRow, {
					variant: "danger",
					icon: h(D.TableRow.Icon, { variant: "danger", source: asset("ic_message_delete") }),
					label: "Reset preferences",
					subLabel: "Reset all per-user preferences back to the default.",
					onPress: () => {
						const next = {};
						for (const k of Object.keys(c.silentCallUsers ?? {})) next[k] = "default";
						store.set({ silentCallUsers: next });
						toast("Silent call preferences have been reset");
					},
				}),
			),

			h(
				D.TableRowGroup,
				{ title: "Remember Audio Output Device" },
				h(D.TableSwitchRow, {
					icon: icon("voice_bar_speaker_new"),
					label: "Remember audio output device",
					subLabel: "Re-applies your preferred output device in calls.",
					value: c.rememberDeviceEnabled,
					onValueChange: (v) => store.set({ rememberDeviceEnabled: v }),
				}),
				h(D.TableRow, {
					disabled: !c.rememberDeviceEnabled || !audio,
					label: "Current device",
					subLabel: device ? `${device.deviceName} - ${audio.text(device)}` : "No device",
					arrow: true,
					onPress: () => audio && chooseDevice(),
				}),
			),

			missing.length
				? h(
						D.TableRowGroup,
						{ title: "Diagnostics (send a screenshot to Claude)" },
						h(D.TableRow, { label: "Not found", subLabel: missing.join("\n") }),
						h(D.TableRow, { label: "finders", subLabel: keys(revenge.modules && revenge.modules.finders) }),
						h(D.TableRow, { label: "filters", subLabel: keys(revenge.modules && revenge.modules.finders && revenge.modules.finders.filters) }),
						h(D.TableRow, { label: "Design", subLabel: keys(D) }),
						h(D.TableRow, { label: "react", subLabel: keys(revenge.react) }),
				  )
				: null,
		),
	);
};

/* ---------------------------------- plugin --------------------------------- */
const options = {
	jsonStorage: { default: DEFAULTS, load: true },

	start(api) {
		jsonStorage = api.jsonStorage;
		missing.length = 0;
		audio = createAudio();

		// Make sure there's a saved device to fall back on
		if (audio) {
			const list = audio.list();
			if (list.length && !savedDevice(list, cfg())) saveDevice(list[0]);
		}

		// --- Silent call: swallow ring() for silent users ---
		const callModule = need("module: call/ring/stopRinging", lookup("call", "ring", "stopRinging"));
		if (callModule) {
			api.cleanup(
				revenge.patcher.instead(callModule, "ring", (args, original) => {
					const c = cfg();
					if (c.silentCallEnabled) {
						const pref = (c.silentCallUsers ?? {})[args[0]] ?? "default";
						const silent = pref === "silent" ? true : pref === "ring" ? false : !!c.silentCallDefault;
						if (silent) return;
					}
					return original(...args);
				}),
			);
		}

		// --- Silent call: bell button next to the call buttons in DMs ---
		const PrivateChannelButtons = need("component: PrivateChannelButtons", findComponent("PrivateChannelButtons"));
		if (PrivateChannelButtons) {
			api.cleanup(
				patchAfter(PrivateChannelButtons, "type", ([props], rt) => {
					const store = jsonStorage;
					const c = store.use() ?? DEFAULTS; // hook: re-renders when the preference changes
					if (!c.silentCallEnabled) return;
					const D = Design();
					if (!D.IconButton) return;

					const channelId = props.channelId;
					const pref = (c.silentCallUsers ?? {})[channelId] ?? "default";
					const info = PREFS[pref] ?? PREFS.default;

					// Structure: <PrivateChannelButtons><Fragment><IconButton/>...
					const frag = rt && rt.props && rt.props.children && rt.props.children[0] && rt.props.children[0].props;
					if (!frag || !Array.isArray(frag.children)) return; // hidden while in a call, object for bot DMs

					frag.children = [
						h(D.IconButton, {
							key: "better-calls:silent-call-toggle",
							icon: asset(info.icon),
							variant: info.variant,
							size: "sm",
							onPress: () => {
								const next = NEXT_PREF[pref] ?? "default";
								store.set({ silentCallUsers: { ...(c.silentCallUsers ?? {}), [channelId]: next } });
								toast(PREFS[next].text, asset(PREFS[next].icon));
							},
						}),
						...frag.children,
					];
				}),
			);
		}

		// --- Remember output device: re-apply it and swap in our own speaker button ---
		const Speaker = need("component: VoicePanelHeaderSpeaker", findComponent("VoicePanelHeaderSpeaker"));
		if (Speaker && audio) {
			api.cleanup(
				patchAfter(Speaker, "type", ([props]) => {
					if (!props.isConnectedToVoiceChannel) return;
					const c = cfg();
					if (!c.rememberDeviceEnabled) return;
					const device = savedDevice(audio.list(), c);
					if (!device) return;

					audio.set(device);

					const D = Design();
					if (!D.IconButton) return;
					return h(D.IconButton, {
						key: "better-calls:output-device-button",
						icon: audio.icon(device.simpleDeviceType),
						variant: "primary-overlay",
						size: "sm",
						onPress: chooseDevice,
					});
				}),
			);
		}
	},

	stop() {
		jsonStorage = undefined;
		audio = undefined;
	},

	SettingsComponent: Settings,
};

return options;
})());
